from django.shortcuts import render, HttpResponse
from time import gmtime, strftime

def index(request):
    context = {
        "time": strftime("%Y-%m-%d %H:%M %p")
    }
    return render(request, "index.html", context)

def book(request):
    return HttpResponse("Hi")