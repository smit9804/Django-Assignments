from django.apps import AppConfig


class TimelyAppConfig(AppConfig):
    name = 'timely_app'
