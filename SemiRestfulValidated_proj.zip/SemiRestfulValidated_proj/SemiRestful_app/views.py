from django.shortcuts import render, redirect
from .models import *
from django.contrib import messages
from time import gmtime, strftime

def shows(request):
    context = {
        "all_shows" : Show.objects.all()
    }
    return render( request, "shows.html", context)

def addShowForm(request):
    context={
        "all_shows" : Show.objects.all()
    }
    return render (request, 'addShowForm.html', context)

def addShow(request):
    errors = Show.objects.basic_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/shows/new')
    else:
        context={
            "all_shows" : Show.objects.all(),
            "date": strftime("%Y-%m-%d")
        }
        title = request.POST['title']
        network = request.POST['network']
        date = request.POST['date']

        Show.objects.create(title=title, network=network, date=date)

    return redirect('/shows')

def showInfo(request, show_id):
    context = {
        "show" : Show.objects.get(id=show_id),
        "date": strftime("%Y-%m-%d")
    }
    return render (request, "showInfoPage.html", context)

def editInfo(request, show_id):
    context = {
        "show" : Show.objects.get(id=show_id)
    }
    return render (request, 'editShowForm.html', context)

def update(request, show_id):
    errors = Show.objects.basic_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f'/shows/' + str(show_id) + '/edit')
    else:
        context ={
        "show" : Show.objects.get(id=show_id),
        "date": strftime("%Y-%m-%d")
        }
        show = Show.objects.get(id=show_id)
        show.title = request.POST['title']
        show.network = request.POST['network']
        show.date = request.POST['date']
        show.desc = request.POST['desc']
        show.save()

        return redirect('/shows')

def destroy(request, show_id):
    context = {
        "show" : Show.objects.get(id=show_id)
    }
    show = Show.objects.get(id=show_id)
    show.delete()

    return redirect ('/shows')
