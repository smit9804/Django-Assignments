from django.apps import AppConfig


class SemirestfulAppConfig(AppConfig):
    name = 'SemiRestful_app'
