from django.db import models

class ShowManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}
        # add keys and values to errors dictionary for each invalid field
        if len(postData['title']) < 2:
            errors["title"] = "Show title name should be at least 5 characters"
        if not postData['date']:
            errors["date"] = "Ya gotta find the release date!"
        if len(postData['network']) < 3:
            errors["network"] = "At least 3 characters are required for the network field"
        if len(postData['desc']) < 10:
            errors['desc'] = "Description field needs to be at least 10 characters."
        return errors

class Show(models.Model):
    title = models.CharField(max_length=255)
    network = models.CharField(max_length=255)
    date = models.DateField()
    desc = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = ShowManager()
    

