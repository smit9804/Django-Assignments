from django.urls import path
from . import views

urlpatterns = [
    path('', views.shows),
    path('shows', views.shows),
    path('shows/create', views.addShow),
    path('shows/new', views.addShowForm),
    path('shows/<int:show_id>', views.showInfo),
    path('shows/<int:show_id>/edit', views.editInfo),
    path('shows/<int:show_id>/update', views.update),
    path('shows/<int:show_id>/destroy', views.destroy)
]