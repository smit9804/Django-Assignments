from django.shortcuts import render, redirect
from django.contrib import messages
from .models import *
import bcrypt

def Using_User(request):
    return User.objects.get(id=request.session['user_id'])

def index(request):
    return render(request, 'login.html')

def login(request):
    user = User.objects.filter(email=request.POST['email'])
    if user:
        logged_user = user[0]
        if bcrypt.checkpw(request.POST['password'].encode(), logged_user.password.encode()):
            request.session['user_id'] = logged_user.id
            return redirect('/main')
    messages.error(request, "Invalid Login Info")
    return redirect ('/')

def register(request):
    errors = User.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
    
        context = {
            "all_users" : User.objects.all()
        }
        email = request.POST['email']
        name = request.POST['name']
        username = request.POST['username']
        password = request.POST['password']
        pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        print(pw_hash)
        

        this_user = User.objects.create(email=email, name=name, username=username, password=pw_hash)
        request.session['user_id'] = this_user.id

    return redirect ('/main')

def main(request):
    if 'user_id' not in request.session:
        return redirect('/')
    context = {
            "all_users" : User.objects.all(),
            "this_user" : User.objects.get(id=request.session['user_id']),
            "allquotes" : Quote.objects.all(),
        }
    return render (request, "main.html", context)

def logout(request):
    del request.session['user_id']
    return redirect('/')

def addquote(request):
    if 'user_id' not in request.session:
        return redirect('/')

    errors = Quote.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/main')
    else:

        user = User.objects.get(id=request.session['user_id'])
        quotedby = request.POST['quotedby']
        message = request.POST['message']
        
        Quote.objects.create(quotedby=quotedby, message=request.POST['message'], user=user)

    return redirect ('/main')

def editQuote(request, quote_id):
    if 'user_id' not in request.session:
        return redirect('/')
    
    this_quote = Quote.objects.get(id=quote_id)

    if this_quote.user.id != request.session['user_id']:
        return redirect('/main')

    context = {
        "quote" : Quote.objects.get(id=quote_id)
    }
    return render (request, 'editQuoteForm.html', context)

def update(request, quote_id):
    if 'user_id' not in request.session:
        return redirect('/')

    errors = Quote.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/main')
    else:
        context = {
        "quote" : Quote.objects.get(id=quote_id)
        }
        quote = Quote.objects.get(id=quote_id)
        quote.quotedby = request.POST['quotedby']
        quote.message = request.POST['message']
        quote.save()

    return redirect('/main')

def userpage(request, user_id):
    if 'user_id' not in request.session:
        return redirect('/')

    context = {
        "posted" : Quote.objects.filter(user_id=user_id),
        "count" : Quote.objects.filter(user_id=user_id).count,
        "user" : User.objects.get(id=request.session['user_id'])
        
    }

    return render (request, "userPage.html", context)

def delete(request, quote_id):
    if 'user_id' not in request.session:
        return redirect('/')

    this_quote = Quote.objects.get(id=quote_id)

    if this_quote.user.id != request.session['user_id']:
        return redirect('/main')

    this_quote.delete()

    return redirect ('/main')