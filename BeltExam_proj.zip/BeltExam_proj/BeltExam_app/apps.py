from django.apps import AppConfig


class BeltexamAppConfig(AppConfig):
    name = 'BeltExam_app'
