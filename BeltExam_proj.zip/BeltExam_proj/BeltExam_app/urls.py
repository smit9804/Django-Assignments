from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('main', views.main),
    path('login', views.login),
    path('logout', views.logout),
    path('register', views.register),
    path('addquote', views.addquote),
    path('user/<int:user_id>', views.userpage),
    path('main/<int:quote_id>/edit', views.editQuote),
    path('main/<int:quote_id>/editquote', views.update),
    path('main/<int:quote_id>/delete', views.delete)
]