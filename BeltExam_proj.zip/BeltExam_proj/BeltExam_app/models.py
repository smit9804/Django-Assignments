from django.db import models
import re

class UserManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}

        if len(postData['email']) < 1:
            errors['email'] = "Please enter an email address"

        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(postData['email']):    # test whether a field matches the pattern            
            errors['email'] = "Invalid email address!"

        try:
            User.objects.get(email=postData['email'])
            errors['email'] = "Invalid email!"
        except:
            pass

        try:
            User.objects.get(username=postData['username'])
            errors['username'] = "Username already taken!"
        except:
            pass

        if len(postData['password']) < 1:
            errors['password'] = "Please enter a valid password"

        if postData['password'] != postData['confpassword']:
            errors['password'] = "Passwords do not match"

        return errors

class User(models.Model):
    email = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    username = models.CharField(max_length=30)
    password = models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()

class QuoteManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}


        if len(postData['quotedby']) < 2:
            errors['quotedby'] = "The ___Quoted___By___ field shall be at least more than 2 characters"

        if len(postData['message']) < 10:
            errors['message'] = "Please enter at least 10 characters in the Quote field!"

        return errors

class Quote(models.Model):
    quotedby = models.CharField(max_length= 100)
    message = models.TextField()
    user = models.ForeignKey(User, related_name="quote", on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = QuoteManager()