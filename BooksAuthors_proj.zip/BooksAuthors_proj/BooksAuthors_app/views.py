from django.shortcuts import render, HttpResponse, redirect
from .models import *

def index(request):
    context = {
        "all_authors" : Authors.objects.all(),
        "all_books" : Books.objects.all()
    }
    return render(request, "index.html", context)

def books(request):
    
    context = {
        "all_authors" : Authors.objects.all(),
        "all_books" : Books.objects.all()
    }
    return render(request, "books.html", context)
    
def authors(request):
    context={
        "all_authors" : Authors.objects.all(),
        "all_books" : Books.objects.all()
    }
    return render (request, "authors.html", context)

def addBook(request):
    print(request.POST['title'])
    Books.objects.create(title=request.POST['title'], desc=request.POST['desc'])
    return redirect('/books')

def addAuthor(request):
    # print(request.POST['first_name'])
    # Authors.objects.create(first_name=request.POST['first_name'], last_name=request.POST['last_name'], notes=request.POST['notes'])
    this_book = Books.objects.get(id=request.POST['books'])
    this_author = Authors.objects.get(id=request.POST['names'])
    this_author.books.add(this_book)
    return redirect('/authors')
