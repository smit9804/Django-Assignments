from django.apps import AppConfig


class BooksauthorsAppConfig(AppConfig):
    name = 'BooksAuthors_app'
