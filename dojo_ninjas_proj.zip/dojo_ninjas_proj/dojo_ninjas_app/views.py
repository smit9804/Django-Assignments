from django.shortcuts import render, redirect
from .models import *

def index(request):
    context = {
        "first_dojo": Dojo.objects.first(),

        "all_dojos" :  Dojo.objects.all()
    }
    return render(request, "index.html", context)

def addDojo(request):
    dojoname = request.POST['dojoname']
    dojocity = request.POST['dojocity']
    dojostate = request.POST['dojostate']

    Dojo.objects.create(name=dojoname, city=dojocity, state=dojostate)

    return redirect ('/')

def addNinja(request):
    firstname = request.POST['firstname']
    lastname = request.POST['lastname']
    dojo = Dojo.objects.get(id=request.POST['dojo'])
    
    Ninja.objects.create(first_name=firstname, last_name=lastname, dojo=dojo)

    return redirect ('/')
