import random
number = random.randint(1,100)

player = input("Hey, what's your name?")
num_guesses = 0
print("What's up " + player + '?' + ' Guess a number between 1 and 100:')

while num_guesses < 5:
    guess = int(input())
    num_guesses += 1
    if guess < number:
        print ('Too low!')
    if guess > number:
        print('Too High!')
    if guess == number:
        break
if guess == number:
    print(' That is correct! Play again?')
else:
    print("You didn't get it right brobeans! :( ")