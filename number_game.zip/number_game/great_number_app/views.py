from django.shortcuts import render, HttpResponse, redirect
from random import randint

def setNum(request):
    request.session['num'] = randint(1,100)

def index(request):
    # return render(request, 'index.html')
    if "num"  not in request.session:
        print("nah player")
        setNum(request)
    else:
        pass
    return render (request, 'index.html')

def guess(request):
    num_guesses = 0
    while num_guesses < 10:
        guess = request.POST['numbah']
        num_guesses += 1
        if (int(guess) < request.session['num']):
            return redirect ('/low')
        if int(guess) > request.session['num']:
            return redirect ('/high')
        if int(guess) == request.session['num']:
            return redirect ('/cool')
    if int(guess) == request.session['num']:
        print(' That is correct! Play again?')
        setNum(request)
    else:
        print("You didn't get it right brobeans! :( ")
    print (request.session['num'])
    return redirect ('/')

def low(request):
    return render (request, 'index2.html')

def high(request):
    return render (request, 'index3.html')

def cool(request):
    return render (request, 'index4.html')


