from django.urls import path 
from . import views

urlpatterns = [
    path('', views.index),
    path('guess', views.guess),
    path('low', views.low),
    path('high', views.high),
    path('cool', views.cool)
]