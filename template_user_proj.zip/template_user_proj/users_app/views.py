from django.shortcuts import render, HttpResponse, redirect
from .models import Users

def index(request):
    context = {
        "all_users": Users.objects.all().values(),
        
    }
    return render(request, "index.html", context)

def addPerson(request):
    name = request.POST['name']
    email = request.POST['email']
    age = request.POST['age']

    Users.objects.create(Name=name, Email_Address=email, Age=age)

    return redirect ('/')