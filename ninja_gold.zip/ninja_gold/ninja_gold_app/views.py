from django.shortcuts import render, redirect
from random import randint

def index(request):
    if 'amount' not in request.session:
        request.session['amount'] = 0
    if 'activities' not in request.session:
        request.session['activities'] = []

    return render (request, 'index.html')

def monies(request):
    if request.method == 'POST':
        if request.POST['build'] == 'farm':
            gold = randint(10, 21)
            request.session['activities'].append("You got " + str(gold) + " gold by farming.")
        
        elif request.POST['build'] == 'cave':
            gold = randint (2, 6)
            request.session['activities'].append("You got " + str(gold) + " gold by hittin' the cave.")

        elif request.POST['build'] == 'house':
            gold = randint (2,5)
            request.session['activities'].append("You got " + str(gold) + " gold by building that dern house there.")

        elif request.POST['build'] == 'casino':
            gold = randint(-50, 50)
            if gold >= 0:
                request.session['activities'].append(" You got " + str(gold) + " gold by winning that moolah at the casino.")
            else:
                request.session['activities'].append(" You lost " + str(gold) + " gold by losing at that casino dude.")

        request.session['amount'] += gold

    return redirect('/')