from django.apps import AppConfig


class DojoSurvayyConfig(AppConfig):
    name = 'dojo_survayy'
