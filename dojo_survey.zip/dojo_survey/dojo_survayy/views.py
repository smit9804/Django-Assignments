from django.shortcuts import render

def index(request):
    return render (request, "index.html")
    

def create(request):
    print("Ya got some stuff?")
    name_from_form = request.POST['name']
    location_from_form = request.POST['location']
    language_from_form = request.POST['language']
    comments_from_form = request.POST['comments']
    context= {
        "name" : name_from_form,
        "location" : location_from_form,
        "language" : language_from_form,
        "comments" : comments_from_form
    }
    return render(request,"showMeDaddy.html", context)