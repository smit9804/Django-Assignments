from django.apps import AppConfig


class CounterrrConfig(AppConfig):
    name = 'counterrr'
