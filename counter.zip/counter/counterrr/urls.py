from django.urls import path
from . import views

urlpatterns =[
    path('', views.sesh),
    path('destroy_session', views.destroy)
]