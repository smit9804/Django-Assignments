from django.shortcuts import render, HttpResponse

def index(request):
    return HttpResponse ("you did it!")

def sesh(request):
    
    if "counter" in request.session:
        print('They do exist!')
        # counter +=1 
        request.session['counter'] +=1
    else:
        print("Negative ghost rider")
        request.session['counter'] = 0
    
    return render (request, 'index.html')

def destroy(request):
    if "counter" in request.session:
        print("yes")
        request.session['counter'] = 0
    else:
        print("no")

    return render (request, 'index.html')
